package by.zborovskaya.task08.entity;

public class CaramelCandy extends Candy{

    public CaramelCandy(String name, int energy, String production, String marking,
                          double proteins, double fats, double carbohydrates,double water,
                        double sugar, double fructose, double vanillin,String dateProduction) {
        super(name,energy,production,marking, proteins,fats,carbohydrates,dateProduction);
    }

    public CaramelCandy(){
        super(new IngredientsCaramel());
    }

    @Override
    public String toString() {
        return "CaramelCandy{" + super.toString()+
                '}';
    }
}
